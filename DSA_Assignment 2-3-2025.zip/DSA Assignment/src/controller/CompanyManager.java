/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import adt.DoublyLinkedList;
import entities.*;
import java.util.Scanner;

/**
 *
 * @author MAMBA
 */
public class CompanyManager {

    private static CompanyManager instance;
    private DoublyLinkedList<Company> company;
    private Scanner scanner = new Scanner(System.in);

    public CompanyManager() {
        company = new DoublyLinkedList<>();
    }

    // Singleton accessor
    public static CompanyManager getInstance() {
        if (instance == null) {
            instance = new CompanyManager();
        }
        return instance;
    }

    public void addTestCompany() {
        Company newCompany = new Company("ABC", "KL", 100, "Good Company", 123123123);
        company.add(newCompany);
        System.out.println("Company added successfully!\n");
        System.out.println("\nRegistration successful! Your Company ID is: " + newCompany.getCompanyId());
    }

    public Company findCompanyById(String companyId) {
        for (Company company : company) {
            if (company.getCompanyId().equals(companyId)) {
                return company;
            }
        }
        System.out.println("Company not existed!");
        return null;
    }

}
