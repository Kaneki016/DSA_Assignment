/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import adt.DoublyLinkedList;
import entities.*;
import java.util.Scanner;

/**
 *
 * @author MAMBA
 */
public class InterviewManager {

    private static InterviewManager instance;
    private DoublyLinkedList<Interview> interview;
    private Scanner scanner = new Scanner(System.in);

    public InterviewManager() {
        interview = new DoublyLinkedList<>();
    }

    // Singleton accessor
    public static InterviewManager getInstance() {
        if (instance == null) {
            instance = new InterviewManager();
        }
        return instance;
    }
    
    
    
    
    
    

}
