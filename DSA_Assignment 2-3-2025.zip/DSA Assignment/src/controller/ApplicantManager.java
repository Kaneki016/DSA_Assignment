package controller;

import adt.DoublyLinkedList;
import entities.Applicant;
import java.util.Scanner;
import boundary.*;

public class ApplicantManager {

    private static ApplicantManager instance;
    private DoublyLinkedList<Applicant> applicants; // Custom DoublyLinkedList to store applicants
    private Scanner scanner = new Scanner(System.in);
    private InputUI inputUI = new InputUI();

    public ApplicantManager() {
        applicants = new DoublyLinkedList<>();
    }

    // Singleton accessor
    public static ApplicantManager getInstance() {
        if (instance == null) {
            instance = new ApplicantManager();
        }
        return instance;
    }

    // Add an applicant
    public void addApplicant(String name, int age, String location, int yearsOfExperience, String educationLevel) {
        Applicant newApplicant = new Applicant(name, age, location, yearsOfExperience, educationLevel);
        applicants.add(newApplicant);
        inputUI.displayMessage("✅ Applicant added successfully!\n");
        inputUI.displayMessage("\n✅ Registration successful! Your Applicant ID is: " + newApplicant.getApplicantId());
    }

    // Remove an applicant by ID
    public void removeApplicant(String applicantId) {
        Applicant toRemove = findApplicantById(applicantId);
        if (toRemove != null) {
            applicants.removeSpecific(toRemove);
            inputUI.displayMessage("✅ Applicant " + applicantId + " removed.\n");
        } else {
            inputUI.displayMessage("❌ Applicant not found!\n");
        }
    }

    // Find an applicant by ID
    public Applicant findApplicantById(String applicantId) {
        for (Applicant applicant : applicants) {
            if (applicant.getApplicantId().equals(applicantId)) {
                return applicant;
            }
        }
        return null;
    }

    // Display all applicants
    public void displayAllApplicants() {
        inputUI.displayMessage("\n=============== List of Applicants ===============");
        if (applicants.isEmpty()) {
            inputUI.displayMessage("❌ No applicants found.\n");
            return;
        }
        for (Applicant applicant : applicants) {
            System.out.println(applicant); // Uses Applicant's toString() method
        }
        inputUI.displayMessage("===============================================\n");
    }

    // Check if an applicant exists
    public boolean isValidApplicant(String applicantId) {
        return findApplicantById(applicantId) != null;
    }

    // View applicant profile
    public void viewApplicantProfile(String applicantId) {
        Applicant applicant = findApplicantById(applicantId);
        if (applicant != null) {
            inputUI.displayMessage("\n===== Applicant Profile =====");
            inputUI.displayMessage(applicant);
            inputUI.displayMessage("==============================\n");
        } else {
            inputUI.displayMessage("❌ Applicant not found!\n");
        }
    }

    // Edit applicant profile
    public void editApplicantProfile() {
        inputUI.displayMessage("Enter your Applicant ID:");
        String applicantId = scanner.nextLine().trim();

        Applicant applicant = findApplicantById(applicantId);
        if (applicant == null) {
            inputUI.displayMessage("❌ Applicant not found!\n");
            return;
        }

        inputUI.displayMessage("\n===== Edit Applicant Profile =====");
        String name = inputUI.getInput("👤 Enter new Name (or press Enter to keep: " + applicant.getName() + "): ");
        if (!name.isEmpty()) {
            applicant.setName(name);
        }
        int age = inputUI.getIntInput("🔢 Enter new Age (or 0 to keep: " + applicant.getAge() + "): ", 18, 100);
        if (age != 0) {
            applicant.setAge(age);
        }
        String location = inputUI.getInput("📍 Enter new Location (or press Enter to keep: " + applicant.getLocation() + "): ");
        if (!location.isEmpty()) {
            applicant.setLocation(location);
        }
        int yearsOfExperience = inputUI.getIntInput("⌛ Enter new Years of Experience (or -1 to keep: " + applicant.getYearsOfExperience() + "): ", 0, 50);
        if (yearsOfExperience != -1) {
            applicant.setYearsOfExperience(yearsOfExperience);
        }
        String educationLevel = inputUI.getInput("🎓 Enter new Education Level (or press Enter to keep: " + applicant.getEducationLevel() + "): ");
        if (!educationLevel.isEmpty()) {
            applicant.setEducationLevel(educationLevel);
        }

        inputUI.displayMessage("\n✅ Profile updated successfully!");
    }

    // Helper method to get valid integer input
    private int getValidIntInput(String message, int min, int max) {
        int value;
        while (true) {
            System.out.print(message);
            if (scanner.hasNextInt()) {
                value = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                if (value >= min && value <= max || value == 0 || value == -1) {
                    return value;
                }
            } else {
                scanner.next(); // Consume invalid input
            }
            System.out.println("❌ Invalid input! Enter a valid number.");
        }
    }
}
