/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modules;

import java.util.Scanner;
import controller.*;
import entities.*;
import boundary.*;

public class ApplicantManagementSystem {

    private static Scanner scanner = new Scanner(System.in);
    private static ApplicantManager applicantManager = ApplicantManager.getInstance();
    private static InputUI inputUI = new InputUI();
    private static MenuUI menuUI = new MenuUI();

    public static void handleMenuChoice(int choice) {
        switch (choice) {
            case 1:
                addApplicant();
                break;

            case 2:
                removeApplicant();
                break;

            case 3:
                applicantManager.displayAllApplicants();
                break;

            case 4:
                searchApplicant();
                break;

            case 5:
                menuUI.exitSystem();
                break;
            default:
                inputUI.invalidMenuSelection(1, 5);
        }
    }



    public static void addApplicant() {
        inputUI.displayMessage("\n✨ ADD NEW APPLICANT ✨");
        String name = inputUI.getInput("👤 Enter Name: ");
        int age = inputUI.getIntInput("🔢 Enter Age: ", 18, 100);
        String location = inputUI.getInput("📍 Enter Location: ");
        int yearsOfExperience = inputUI.getIntInput("⌛ Enter Years of Experience: ", 0, 50);
        String educationLevel = inputUI.getInput("🎓 Enter Education Level: ");

        // Create and add the new applicant
        applicantManager.addApplicant(name, age, location, yearsOfExperience, educationLevel);

        // Success message
        inputUI.displayMessage("\n✅ Applicant added successfully!");
        inputUI.displayMessage("📌 Name: " + name + "| Age: " + age + " | Location: " + location + " | Experience: " + yearsOfExperience + " years | Education: " + educationLevel);
    }

    public static void removeApplicant() {
        inputUI.displayMessage("Enter the Applicant ID to remove!");
        String id = scanner.nextLine().trim();
        if (id.isEmpty()) {
            inputUI.displayMessage("❌ Applicant ID cannot be empty!");
            return;
        }
        applicantManager.removeApplicant(id);
    }

    public static void searchApplicant() {
        inputUI.displayMessage("Enter Applicant ID to search: ");
        String id = scanner.nextLine().trim();
        if (id.isEmpty()) {
            inputUI.displayMessage("❌ Applicant ID cannot be empty!");
            return;
        }
        Applicant foundApplicant = applicantManager.findApplicantById(id);
        inputUI.displayMessage(foundApplicant != null ? "\n✅ Applicant Found:\n" + foundApplicant : "❌ Applicant not found.");
    }
}
