package modules;

import controller.ApplicantManager;
import java.util.Scanner;
import boundary.*;

public class ClientLogin {

    private static Scanner scanner = new Scanner(System.in);
    private static ApplicantManager applicantManager = ApplicantManager.getInstance();
    private static String loggedInApplicant = null;

    //Boundary
    private static MenuUI menuUI = new MenuUI();
    private static InputUI inputUI = new InputUI();

    public static void displayClientMenu() {
        int choice;
        do {
            menuUI.displayClientMainMenu();

            while (!scanner.hasNextInt()) {
                inputUI.invalidMenuSelection(1, 3);
                scanner.next();
            }
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    registerApplicant();
                    break;
                case 2:
                    applicantManager.editApplicantProfile();
                    break;
                case 3:
                    menuUI.exitSystem();
                    break; // Add break here to prevent fall-through
                default:
                    inputUI.invalidMenuSelection(1, 3);
                    break; // Add break here to prevent fall-through
            }
        } while (choice != 3);
    }

    public static void registerApplicant() {
        inputUI.displayMessage("\n✨ REGISTER NEW APPLICANT ✨");
        String name = inputUI.getInput("👤 Enter Name: ");
        int age = inputUI.getIntInput("🔢 Enter Age: ", 18, 100);
        String location = inputUI.getInput("📍 Enter Location: ");
        int yearsOfExperience = inputUI.getIntInput("⌛ Enter Years of Experience: ", 0, 50);
        String educationLevel = inputUI.getInput("🎓 Enter Education Level: ");

        // Register applicant
        applicantManager.addApplicant(name, age, location, yearsOfExperience, educationLevel);

        System.out.println("Please login to continue.");
    }

}
