/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modules;

import java.util.Scanner;
import controller.ApplicantManager;
import entities.*;
import boundary.*;

public class MainSystem {

    Scanner scanner = new Scanner(System.in);
    int choice = 0;
    //Module System
    private static ApplicantManagementSystem applicantSystem = new ApplicantManagementSystem();
    private static ClientLogin clientLogin = new ClientLogin();
    private static InterviewManagementSystem interviewSystem = new InterviewManagementSystem();
    
    //Boundary
    private static MenuUI menuUI = new MenuUI();
    private static InputUI inputUI = new InputUI();
    
    //Controller
    private static ApplicantManager applicantManager = ApplicantManager.getInstance();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice = 0;
        do {
            menuUI.displayMainMenu();
            choice = inputUI.getValidIntInput("Enter your choice: ", 1, 3);
            handleMenuChoice(choice);
        } while (choice != 4);
    }



    public static void handleMenuChoice(int choice) {
        switch (choice) {
            case 1:
                //Applicant sides
                clientLogin.displayClientMenu();
                break;

            case 2:
                //Middle side
                menuUI.displayMiddleMainMenu();
                choice = inputUI.getValidIntInput("Enter your choice: ", 1, 2);
                switch (choice) {
                    case 1:
                        menuUI.displayApplicantMenu();
                        choice = inputUI.getValidIntInput("Enter your choice: ", 1, 5);
                        applicantSystem.handleMenuChoice(choice);
                        break;
                    default:
                }
                break;
            // End Middle side
            case 3:
                //Company side
                menuUI.displayCompanyMainMenu();
                choice = inputUI.getValidIntInput("Enter your choice: ", 1, 5);
                switch (choice) {
                    case 1:
                        //Add Job
                    case 4:
                        interviewSystem.displayMenu();
                        break;
                    default:
                }

                //End Compant side
                break;
            case 4:
                System.out.println("Exiting the system. Goodbye!");
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

}
