/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modules;

import controller.*;
import java.util.Scanner;
import entities.*;

/**
 *
 * @author MAMBA
 */
public class InterviewManagementSystem {

    private static Scanner scanner = new Scanner(System.in);
    private static Company company;
    private static ApplicantManager applicantManager = ApplicantManager.getInstance();
    private static InterviewManager interviewManager = InterviewManager.getInstance();
    private static CompanyManager companyManager = CompanyManager.getInstance();

    
    public static void displayMenu() {
        
        System.out.print("Which company you belongs to?: ");
        String companyId = scanner.nextLine().trim();
        companyManager.addTestCompany();
        company = companyManager.findCompanyById(companyId);   
       
    }

}
