package controller;

import adt.DoublyLinkedList;
import entities.Applicant;

public class ApplicantManager {

    private DoublyLinkedList<Applicant> applicants; // Custom DoublyLinkedList to store applicants

    public ApplicantManager() {
        applicants = new DoublyLinkedList<>();
    }

    // Add an applicant
    public void addApplicant(String name, int age, String location, int yearsOfExperience, String educationLevel) {
        Applicant newApplicant = new Applicant(name, age, location, yearsOfExperience, educationLevel);
        applicants.add(newApplicant);
        System.out.println("✅ Applicant added successfully!\n");
    }

    // Remove an applicant by ID
    public void removeApplicant(String applicantId) {
        Applicant toRemove = findApplicantById(applicantId);
        if (toRemove != null) {
            applicants.removeSpecific(toRemove);
            System.out.println("✅ Applicant " + applicantId + " removed.\n");
        } else {
            System.out.println("❌ Applicant not found!\n");
        }
    }

    // Find an applicant by ID
    public Applicant findApplicantById(String applicantId) {
        for (Applicant applicant : applicants) {
            if (applicant.getApplicantId().equals(applicantId)) {
                return applicant;
            }
        }
        return null;
    }

    // Display all applicants
    public void displayAllApplicants() {
        System.out.println("\n===== List of Applicants =====");
        if (applicants.isEmpty()) {
            System.out.println("❌ No applicants found.\n");
            return;
        }
        for (Applicant applicant : applicants) {
            System.out.println(applicant); // Uses Applicant's toString() method
        }
        System.out.println("================================\n");
    }
}
