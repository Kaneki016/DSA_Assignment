package entities;

import adt.DoublyLinkedList;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Applicant {
    private static int nextId = 1;  // Auto-increment ID counter

    private String applicantId;
    private String name;
    private int age;
    private String location;
    private int yearsOfExperience;
    private String educationLevel;
    private String dateAdded; // Store date when applicant is created

    // Constructor
    public Applicant(String name,int age, String location, int yearsOfExperience, String educationLevel) {
        this.applicantId = String.format("A%03d", nextId++);  // Generates A001, A002, ...
        this.name = name;
        this.location = location;
        this.age=age;
        this.educationLevel=educationLevel;
        this.yearsOfExperience = yearsOfExperience;
        this.dateAdded = getCurrentDateTime();  // Set timestamp when created
    }

    // Get current date and time in formatted string
    private String getCurrentDateTime() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return now.format(formatter);
    }

    // Getters and setters
    public String getApplicantId() { return applicantId; }
    public String getName() { return name; }
    public String getLocation() { return location; }
    public int getYearsOfExperience() { return yearsOfExperience; }
    public String getEducationLevel() { return educationLevel; }
    public String getDateAdded() { return dateAdded; }

    @Override
    public String toString() {
        return String.format("ID: %s, Name: %s, Location: %s, Experience: %d years, Education: %s, " +
                ", Date Added: %s", 
                applicantId, name, location, yearsOfExperience, educationLevel,  dateAdded);
    }
}
