/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modules;

import java.util.Scanner;
import controller.ApplicantManager;
import entities.Applicant;

public class ApplicantManagementSystem {

    private static Scanner scanner = new Scanner(System.in);
    private static ApplicantManager applicantManager = new ApplicantManager();

    public static void main(String[] args) {
        int choice;
        do {
            displayMenu();
            choice = getValidIntInput("Enter your choice: ", 1, 5);
            handleMenuChoice(choice);
        } while (choice != 5);
    }

    private static void displayMenu() {
        System.out.println("\n===== Applicant Management Menu =====");
        System.out.println("1. Add Applicant");
        System.out.println("2. Remove Applicant");
        System.out.println("3. View All Applicants");
        System.out.println("4. Search Applicant by ID");
        System.out.println("5. Exit");
    }

    private static void handleMenuChoice(int choice) {
        switch (choice) {
            case 1:
                addApplicant();
                break;

            case 2:
                removeApplicant();
                break;

            case 3:
                applicantManager.displayAllApplicants();
                break;

            case 4:
                searchApplicant();
                break;

            case 5:
                System.out.println("Exiting Applicant Management Module...");
                break;
            default:
                System.out.println("❌ Invalid choice! Please enter a number between 1-5.");
        }
    }

    private static int getValidIntInput(String prompt, int min, int max) {
        int num;
        while (true) {
            System.out.print(prompt);
            if (scanner.hasNextInt()) {
                num = scanner.nextInt();
                if (num >= min && num <= max) {
                    scanner.nextLine(); // Consume newline
                    return num;
                }
            } else {
                scanner.next(); // Clear invalid input
            }
            System.out.println("❌ Invalid input! Please enter a number between " + min + " and " + max + ".");
        }
    }

    private static void addApplicant() {
        System.out.println("\n✨ ADD NEW APPLICANT ✨");

        System.out.print("👤 Enter Name: ");
        String name = scanner.nextLine().trim();
        while (name.isEmpty()) {
            System.out.print("❌ Name cannot be empty! Please enter again: ");
            name = scanner.nextLine().trim();
        }

        int age = getValidIntInput("🔢 Enter Age: ", 18, 100);
        System.out.print("📍 Enter Location: ");
        String location = scanner.nextLine().trim();
        while (location.isEmpty()) {
            System.out.print("❌ Location cannot be empty! Please enter again: ");
            location = scanner.nextLine().trim();
        }

        int yearsOfExperience = getValidIntInput("⌛ Enter Years of Experience: ", 0, 50);
        System.out.print("🎓 Enter Education Level: ");
        String educationLevel = scanner.nextLine().trim();
        while (educationLevel.isEmpty()) {
            System.out.print("❌ Education Level cannot be empty! Please enter again: ");
            educationLevel = scanner.nextLine().trim();
        }

        // Create and add the new applicant
        applicantManager.addApplicant(name, age, location, yearsOfExperience, educationLevel);

        // Success message
        System.out.println("\n✅ Applicant added successfully!");
        System.out.printf("📌 Name: %s | Age: %d | Location: %s | Experience: %d years | Education: %s%n",
                name, age, location, yearsOfExperience, educationLevel);
    }

    private static void removeApplicant() {
        System.out.print("Enter Applicant ID to remove: ");
        String id = scanner.nextLine().trim();
        if (id.isEmpty()) {
            System.out.println("❌ Applicant ID cannot be empty!");
            return;
        }
        applicantManager.removeApplicant(id);
    }

    private static void searchApplicant() {
        System.out.print("Enter Applicant ID to search: ");
        String id = scanner.nextLine().trim();
        if (id.isEmpty()) {
            System.out.println("❌ Applicant ID cannot be empty!");
            return;
        }
        Applicant foundApplicant = applicantManager.findApplicantById(id);
        System.out.println(foundApplicant != null ? "\n✅ Applicant Found:\n" + foundApplicant : "❌ Applicant not found.");
    }
}
