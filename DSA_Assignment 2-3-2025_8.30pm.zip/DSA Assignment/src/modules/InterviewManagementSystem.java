/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modules;

import java.util.Scanner;
import controller.*;
import entities.*;
import boundary.*;

/**
 *
 * @author MAMBA
 */
public class InterviewManagementSystem {

    private static Scanner scanner = new Scanner(System.in);
    private static Company company;
    
    //Controller
    private static ApplicantManager applicantManager = ApplicantManager.getInstance();
    private static InterviewManager interviewManager = InterviewManager.getInstance();
    private static CompanyManager companyManager = CompanyManager.getInstance();
    
    //Boundary
    private static InputUI inputUI = new InputUI();
    private static MenuUI menuUI = new MenuUI();

    
    public static void displayMenu() {
        inputUI.displayMessage("Which company you belongs to?: ");
        String companyId = scanner.nextLine().trim();
        companyManager.addTestCompany();
        company = companyManager.findCompanyById(companyId);
        
        if (company == null) {
            inputUI.displayMessage("Company not found!");
        } 
        
        menuUI.displayAppliedApplicantInterviewMenu(company.getCompanyName());
        interviewManager.viewCompanyAppliedApplicant(company);
        
        
        
        
        
       
    }

}
