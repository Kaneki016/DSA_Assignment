package entities;

public class Interview {

    // Static counter for automatically assigning unique IDs, starting at 1000
    private static int nextId = 1;  // Auto-increment ID counter

    // Fields for the Interview
    private String interviewId;
    private ApplicantAppliedJob applicantAppliedJob;
    private String time;      
    private String location;  
    private String mode;      
    private String status;   
    private String feedback;  

    public Interview(ApplicantAppliedJob applicantAppliedJob, String time, String location, String mode, String status, String feedback) {
        this.interviewId = String.format("I%03d", nextId++); // Assign current ID and increment for the next Company
        this.applicantAppliedJob = applicantAppliedJob;
        this.time = time;
        this.location = location;
        this.mode = mode;
        this.status = status;
        this.feedback = feedback;
    }

    public String getInterviewId() {
        return interviewId;
    }

    public ApplicantAppliedJob getApplicantAppliedJob() {
        return applicantAppliedJob;
    }

    public String getTime() {
        return time;
    }

    public String getLocation() {
        return location;
    }

    public String getMode() {
        return mode;
    }

    public String getStatus() {
        return status;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setInterviewId(String interviewId) {
        this.interviewId = interviewId;
    }

    public void setApplicantAppliedJob(ApplicantAppliedJob applicantAppliedJob) {
        this.applicantAppliedJob = applicantAppliedJob;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    
}
