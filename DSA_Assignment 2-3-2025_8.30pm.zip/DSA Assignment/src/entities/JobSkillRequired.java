/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

/**
 *
 * @author MAMBA
 */
public class JobSkillRequired {

    private Skill skill;
    private Job job;

    public JobSkillRequired(Skill skill, Job job) {
        this.skill = skill;
        this.job = job;
    }

    public Skill getSkill() {
        return skill;
    }

    public Job getJob() {
        return job;
    }

    public void setSkill(Skill skill) {
        this.skill = skill;
    }

    public void setJob(Job job) {
        this.job = job;
    }
    
    

}
