/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package boundary;

/**
 *
 * @author MAMBA
 */
public class MenuUI {

    public static void displayMainMenu() {
        System.out.println("\n===== Main Menu =====");
        System.out.println("Which side are you?");
        System.out.println("1. Client");
        System.out.println("2. Middle");
        System.out.println("3. Company");
    }

    public static void displayClientMainMenu() {
        System.out.println("\n===== Client Side =====");
        System.out.println("1. Register as a New Applicant");
        System.out.println("2. Edit Applicant");
        System.out.println("3. Exit");
        System.out.print("Enter your choice: ");
    }

    public static void displayMiddleMainMenu() {
        System.out.println("\n===== Middile Side Menu =====");
        System.out.println("1. Applicant Management");
    }

    public static void displayCompanyMainMenu() {
        System.out.println("\n===== Company Side Menu =====");
        System.out.println("1. Add Job Post ");
        System.out.println("2. Edit Job Post ");
        System.out.println("3. Remove Job Post ");
        System.out.println("4. View Applied Applicant");
        System.out.println("5. Assign and View Interview Slot");
    }

    public static void displayApplicantMenu() {
        System.out.println("\n===== Applicant Management Menu =====");
        System.out.println("1. Add Applicant");
        System.out.println("2. Remove Applicant");
        System.out.println("3. View All Applicants");
        System.out.println("4. Search Applicant by ID");
        System.out.println("5. Exit");
    }

    public static void displayAppliedApplicantInterviewMenu(String company) {
        System.out.println("\n===== Company " + company + " list of applied applicant.=====");
    }

    public static void exitSystem() {
        System.out.println("Exiting...");
    }

}
