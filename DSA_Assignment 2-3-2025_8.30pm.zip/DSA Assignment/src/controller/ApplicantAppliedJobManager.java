package controller;

import adt.DoublyLinkedList;
import entities.ApplicantAppliedJob;
import boundary.InputUI;

public class ApplicantAppliedJobManager {

    private static ApplicantAppliedJobManager instance;
    private DoublyLinkedList<ApplicantAppliedJob> applicantAppliedJob; 
    private static InputUI inputUI = new InputUI();
   
    public ApplicantAppliedJobManager() {
        applicantAppliedJob = new DoublyLinkedList<>();
    }

    public static ApplicantAppliedJobManager getInstance() {
        if (instance == null) {
            instance = new ApplicantAppliedJobManager();
        }
        return instance;
    }

    public void addApplicantAppliedJob(ApplicantAppliedJob newAppliedJob) {
        applicantAppliedJob.add(newAppliedJob);
        inputUI.displayMessage("A new applicant applied job added!\n");
    }
    
    // New getter method to expose the list
    public DoublyLinkedList<ApplicantAppliedJob> getApplicantAppliedJobs() {
        return applicantAppliedJob;
    }
}
