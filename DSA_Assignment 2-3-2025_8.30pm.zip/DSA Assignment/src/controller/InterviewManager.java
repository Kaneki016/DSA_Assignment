package controller;

import adt.DoublyLinkedList;
import entities.ApplicantAppliedJob;
import entities.Company;

public class InterviewManager {

    private static InterviewManager instance;
    private DoublyLinkedList<?> interview; // Existing interview list (if needed)
    
    // Get shared instances of other controllers
    private static ApplicantManager applicantManager = ApplicantManager.getInstance();
    private static ApplicantAppliedJobManager applicantAppliedJobManager = ApplicantAppliedJobManager.getInstance();

    private InterviewManager() {
        // Initialize interview list if needed
    }

    public static InterviewManager getInstance() {
        if (instance == null) {
            instance = new InterviewManager();
        }
        return instance;
    }
    
    // This method finds and prints the applicants who applied to the specified company
    public void viewCompanyAppliedApplicant(Company company) {
        DoublyLinkedList<ApplicantAppliedJob> appliedJobs = applicantAppliedJobManager.getApplicantAppliedJobs();
        
        System.out.println("\n===== Applicants Applied to " + company.getCompanyName() + " =====");
        boolean found = false;
        
        for (ApplicantAppliedJob aaj : appliedJobs) {
            // Assuming that each ApplicantAppliedJob has a method getJobPost() 
            // and JobPost has a method getCompany() returning a Company object.
            if (aaj.getJobPost().getCompany().getCompanyName().equalsIgnoreCase(company.getCompanyName())) {
                // Assuming ApplicantAppliedJob has a method getApplicant() to get the Applicant
                System.out.println(aaj.getApplicant());
                found = true;
            }
        }
        
        if (!found) {
            System.out.println("No applicants found for " + company.getCompanyName() + ".");
        }
    }
}
