/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import adt.DoublyLinkedList;
import entities.*;
import controller.*;
import java.util.Scanner;

/**
 *
 * @author MAMBA
 */
public class CompanyManager {

    private Scanner scanner = new Scanner(System.in);

    //Instance Definer
    private static CompanyManager instance;

    // Singleton accessor
    public static CompanyManager getInstance() {
        if (instance == null) {
            instance = new CompanyManager();
        }
        return instance;
    }

    //Doubly Linked List ADT
    private DoublyLinkedList<Company> company;
    private DoublyLinkedList<Skill> skill = new DoublyLinkedList<>();
    private DoublyLinkedList<Job> job = new DoublyLinkedList<>();
    private DoublyLinkedList<JobSkillRequired> jobskillrequired = new DoublyLinkedList<>();
    private DoublyLinkedList<JobPost> jobpost = new DoublyLinkedList<>();
    private DoublyLinkedList<ApplicantAppliedJob> applicantappliedjob = new DoublyLinkedList<>();
    private DoublyLinkedList<Interview> interview = new DoublyLinkedList<>();

    //Controller 
    //---Applicant Manager get available instances
    private static ApplicantManager applicantManager = ApplicantManager.getInstance();
    private static ApplicantAppliedJobManager applicantAppliedJobManager = ApplicantAppliedJobManager.getInstance();

    public CompanyManager() {
        company = new DoublyLinkedList<>();
    }

    //Test function for mock data
    public void addTestCompany() {
        Applicant applicant1 = new Applicant("Lim", 18, "KL", 3, "Degree");
        Applicant applicant2 = new Applicant("DeDek", 50, "KLTT", 3, "Degree");
        Applicant applicant3 = new Applicant("Tetej", 30, "KLDF", 3, "Master");
        Company newCompany = new Company("ABC", "KL", 100, "Good Company", 123123123);
        Company newCompany2 = new Company("DBC", "TH", 10, "Good Company", 123123123);
        Skill newSkill = new Skill("Leadership", "Mental", 3);
        Job newJob = new Job("Software Engineer", newCompany, "KL", 3, newSkill, 3000);
        Job newJob2 = new Job("Data Engineer", newCompany2, "KL", 3, newSkill, 3000);
        JobSkillRequired jsR1 = new JobSkillRequired(newSkill, newJob);
        JobSkillRequired jsR2 = new JobSkillRequired(newSkill, newJob2);
        JobPost jp1 = new JobPost(newJob, newCompany);
        JobPost jp2 = new JobPost(newJob2, newCompany2);
        ApplicantAppliedJob aaj1 = new ApplicantAppliedJob(applicant1, jp1);
        ApplicantAppliedJob aaj2 = new ApplicantAppliedJob(applicant2, jp2);
        ApplicantAppliedJob aaj3 = new ApplicantAppliedJob(applicant3, jp1);

        Interview interview1 = new Interview(aaj1, "3.00pm", "KL", "Zoom", "Waiting", "none");
        applicantManager.addApplicant(applicant1);
        applicantManager.addApplicant(applicant2);
        applicantManager.addApplicant(applicant3);
        company.add(newCompany);
        company.add(newCompany2);
        skill.add(newSkill);
        job.add(newJob);
        job.add(newJob2);
        jobpost.add(jp1);
        jobpost.add(jp2);
        jobskillrequired.add(jsR1);
        jobskillrequired.add(jsR2);
        applicantAppliedJobManager.addApplicantAppliedJob(aaj1);
        applicantAppliedJobManager.addApplicantAppliedJob(aaj2);
        applicantAppliedJobManager.addApplicantAppliedJob(aaj3);
        interview.add(interview1);
        System.out.println("Company added successfully!\n");
        System.out.println("\nRegistration successful! Your Company ID is: " + newCompany.getCompanyId());

    }

    //Find Company based on companyId
    public Company findCompanyById(String companyId) {
        for (Company company : company) {
            if (company.getCompanyId().equals(companyId)) {
                return company;
            }
        }
        System.out.println("Company not existed!");
        return null;
    }

}
